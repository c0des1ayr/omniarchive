# MANTLE High-Quality Audio Pack (Masten CE / Mesen 2)

Replaces MANTLE's NES FamiStudio music with high-quality `.ogg` audio files
using Masten CE's NES Enhanced Audio (NEA) HD pack feature.

## Folder layout

```
HdPacks/mantle/
  hires.txt        # manifest: maps NEA album/track to .ogg files
  README.md        # this file
  music/
    intro.ogg          # song 0  - INTRO
    ocean.ogg          # song 1  - OCEAN
    sword.ogg          # song 2  - SWORD
    sword2.ogg         # song 3  - SWORD 2 (SWORD_SLOW)
    northernlight.ogg  # song 4  - NORTHERNLIGHT
    northernlight2.ogg # song 5  - NORTHERNLIGHT 2
    glaceir.ogg        # song 6  - GLACEIR
    bit_roots.ogg      # song 7  - BIT ROOTS
    eram.ogg           # song 8  - ERAM
    burning_eyes.ogg   # song 9  - BURNING EYES
    twisted.ogg        # song 10 - TWISTED
```

## How it works

1. **Provide audio files.** Export/render each mantle track as `.ogg` (Vorbis)
   and place them in `music/` with the names above. Masten CE expects `.ogg`.
2. **Patch the ROM.** The stock mantle ROM plays music through its internal
   FamiStudio engine and never writes to Masten CE's NEA registers, so a
   sound pack alone will not produce audio. You must build a patched ROM that:
   - Detects NEA (reads $4102-$4104 signature "NEA")
   - On `music_play()`, writes album to $4104 and track to $4105
   - On `music_stop()`, writes stop to $4101
   - Skips internal FamiStudio music playback when NEA is active
   - Keeps NES SFX working via FamiStudio's SFX channel
   See the source patches below (`source/c/system-defines.h`, `utils.c`,
   `utils.h`, `main.c`).
3. **Load in Masten CE.** Launch the patched `mantle.nes` in Masten CE
   (2.2.1). The emulator matches the pack by ROM filename (`mantle`) and
   plays the `.ogg` tracks instead of the NES music.

## Build

From the mantle repo root:

```
create-nes-game build
```

Then copy `rom/mantle.nes` over `~/Games/ROMs/Nintendo/Homebrew/mantle.nes`
and launch it in Masten CE.

## Notes

- The pack is matched by ROM filename. If you rename the ROM, rename the
  `HdPacks/<name>/` folder to match.
- Looping is controlled by the patched game code via $4100 (bit 0 = loop).
- SFX remain as NES audio unless you also patch SFX to use $4106.
